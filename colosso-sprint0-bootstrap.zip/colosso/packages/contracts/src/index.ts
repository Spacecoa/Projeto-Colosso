export type DecisionClass='O'|'Q'|'C'|'E';
export type Visibility='public'|'restricted'|'confidential';
export type EvidenceConfidenceLevel='D0'|'D1'|'D2'|'D3'|'D4';
export type ApprovalDomain='OPERATIONS'|'SECURITY'|'FIDUCIARY'|'AUDIT';
export interface DomainEvent<T=unknown>{event_id:string;event_type:string;event_version:string;occurred_at:string;producer:string;tenant_id:string;correlation_id:string;causation_id?:string;payload:T;}
