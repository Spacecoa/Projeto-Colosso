import { Body, Controller, Post } from '@nestjs/common';
import { OpaClient, PolicyInput } from './opa.client';
@Controller('policies') export class PolicyController {constructor(private readonly opa:OpaClient){} @Post('evaluate') evaluate(@Body() input:PolicyInput){return this.opa.evaluate(input);}}
