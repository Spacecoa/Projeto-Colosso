import { Module } from '@nestjs/common';
import { HealthController } from './health/health.controller';
import { PolicyController } from './policy/policy.controller';
import { OpaClient } from './policy/opa.client';
@Module({controllers:[HealthController,PolicyController],providers:[OpaClient]}) export class AppModule {}
