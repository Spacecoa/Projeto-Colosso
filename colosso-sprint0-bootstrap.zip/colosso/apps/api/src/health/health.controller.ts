import { Controller, Get } from '@nestjs/common';
@Controller('health') export class HealthController {@Get() health(){return {status:'ok',service:'colosso-api',track:'A',scope:'pre-mvp'};}}
