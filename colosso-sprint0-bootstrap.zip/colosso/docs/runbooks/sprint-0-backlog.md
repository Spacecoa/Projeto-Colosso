# Sprint 0 — Backlog técnico

1. Monorepo/workspaces.
2. Lint/format/typecheck/CI.
3. PostgreSQL + migrations.
4. Keycloak/OIDC.
5. Propagação `org_id`.
6. RLS.
7. OPA deny-by-default.
8. Contract tests.
9. Structured logs/correlation_id.
10. OpenTelemetry.
11. Transactional outbox.
12. Envelope de eventos.
13. Worker idempotente.
14. Audit append-only/hash chain particionada.
15. Root digest/WORM design.
16. Tenant isolation suite.
17. Docker Compose.
18. ADR-005 benchmark.
19. Threat model.
20. E2E DoD.

## DoD
Org A -> A = 200; Org A -> B = 403; negativa auditada; policy/version rastreável; trace presente.
