# Threat Model — Sprint 0

## Ameaças prioritárias
1. Cross-tenant leak por bug de filtro.
2. Bypass do Policy Engine.
3. Token roubado/revogado aceito.
4. Alteração retroativa de audit log.
5. Secret em arquivo/DB de aplicação.
6. Confused deputy.
7. Replay/duplicação de evento.
8. Falha entre commit e publicação.

## Controles
RLS + OPA deny-by-default + tenant context + policy decision log + outbox + idempotência + audit append-only + tenant isolation tests.

## Critério de saída
Org A lê A=200; Org A lê B=403; tentativa auditada; policy/version rastreável; trace presente.
