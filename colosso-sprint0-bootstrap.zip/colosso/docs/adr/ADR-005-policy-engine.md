# ADR-005 — Motor ABAC: OPA/Rego no Pré-MVP

**Status:** Proposed for Sprint 0 validation

Usar OPA/Rego atrás de uma Policy Decision API. O domínio não dependerá da sintaxe Rego; contratos de entrada/saída ficam em `packages/contracts`. Fechar após benchmark de latência, explainability, DX e suporte a obligations.
