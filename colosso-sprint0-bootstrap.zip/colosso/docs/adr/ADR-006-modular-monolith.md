# ADR-006 — Monólito modular no Pré-MVP

**Status:** Accepted

O backend de domínio nasce como monólito modular. Extração exige motivo mensurável: escala, isolamento, ciclo de deploy ou ownership.
