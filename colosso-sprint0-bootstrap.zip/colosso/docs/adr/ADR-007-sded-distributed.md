# ADR-007 — SDED distribuído, sem registro central agregado

**Status:** Accepted

`DependencyAssessment` é escopado por organização/finalidade. Qualquer agregação futura pertence à Trilha B e exige novo Gate jurídico e de segurança.
