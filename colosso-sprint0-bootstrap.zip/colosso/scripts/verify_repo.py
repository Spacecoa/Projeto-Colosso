from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
required=['package.json','README.md','infra/docker/docker-compose.yml','infra/migrations/001_bootstrap.sql','infra/keycloak/realm-colosso.json','infra/opa/policies/authz.rego','docs/openapi/policies.openapi.yaml','docs/adr/ADR-005-policy-engine.md','docs/adr/ADR-006-modular-monolith.md','docs/adr/ADR-007-sded-distributed.md']
missing=[p for p in required if not (root/p).exists()]
if missing: print('Missing:',*missing,sep='\n - '); sys.exit(1)
json.loads((root/'package.json').read_text()); json.loads((root/'infra/keycloak/realm-colosso.json').read_text())
sql=(root/'infra/migrations/001_bootstrap.sql').read_text()
for m in ['ENABLE ROW LEVEL SECURITY','outbox_event','audit_event','evidence_confidence_level']: assert m in sql
rego=(root/'infra/opa/policies/authz.rego').read_text(); assert 'default decision' in rego and 'supplier_match' in rego
print('Colosso Sprint 0 scaffold: static verification OK')
