import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
const sql=fs.readFileSync('infra/migrations/001_bootstrap.sql','utf8');
test('RLS core tables',()=>{for(const t of ['app_user','productive_passport','evidence','data_classification','outbox_event']) assert.match(sql,new RegExp(`ALTER TABLE ${t} ENABLE ROW LEVEL SECURITY`,'i'));});
test('audit append-only permissions',()=>assert.match(sql,/REVOKE UPDATE, DELETE ON audit_event FROM PUBLIC/i));
