import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
test('baseline artifacts exist',()=>{for(const p of ['infra/migrations/001_bootstrap.sql','infra/opa/policies/authz.rego','docs/openapi/policies.openapi.yaml','docs/threat-model/sprint-0.md']) assert.ok(fs.existsSync(p),`${p} must exist`);});
