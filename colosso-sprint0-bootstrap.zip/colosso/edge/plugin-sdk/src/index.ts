export interface ConnectorMetadata{name:string;version:string;protocol:string}
export interface ConnectorContext{deviceId:string;orgId:string}
export interface HealthResult{healthy:boolean;details?:Record<string,unknown>}
export interface ReadRequest{cursor?:string;limit?:number}
export interface RawRecord{sourceId:string;payload:unknown;observedAt:string}
export interface SanitizationPolicy{allowedFields:string[];deniedFields?:string[]}
export interface ColossoRecord{sourceId:string;payload:unknown;observedAt:string}
export interface ColossoConnector{metadata():ConnectorMetadata;init(context:ConnectorContext):Promise<void>;health():Promise<HealthResult>;read(request:ReadRequest):Promise<RawRecord[]>;transform(records:RawRecord[],policy:SanitizationPolicy):Promise<ColossoRecord[]>;shutdown():Promise<void>;}
