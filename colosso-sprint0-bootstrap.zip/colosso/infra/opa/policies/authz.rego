package colosso.authz
import rego.v1
default decision := {"allow":false,"reason":"default_deny","obligations":["audit_access"]}
is_owner if input.subject.org_id == input.resource.owner_org_id
is_public if input.resource.visibility == "public"
decision := {"allow":true,"reason":"owner_access","policy_id":"baseline-owner-v1","policy_version":1,"obligations":["audit_access"]} if { is_owner }
decision := {"allow":true,"reason":"public_read","policy_id":"baseline-public-v1","policy_version":1,"obligations":["audit_access"]} if { input.action == "read"; is_public }
decision := {"allow":true,"reason":"supplier_match_masked","policy_id":"baseline-match-v1","policy_version":1,"obligations":["mask_supplier_identity","audit_access"]} if { input.action == "read"; input.resource.visibility == "restricted"; input.context.purpose == "supplier_match"; input.context.competitive_relation == "unknown" }
