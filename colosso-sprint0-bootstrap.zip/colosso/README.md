# Projeto Colosso — Trilha A / Pré-MVP

Bootstrap técnico baseado no SRS 0.2 e no Blueprint aprovado para a Sprint 0.

## Estado
Este repositório **não representa o Gate 3 aprovado**. É um artefato de engenharia enquanto Gates de Mercado, Funding e Jurídico permanecem separados.

## Sprint 0
- PostgreSQL com RLS multi-tenant
- OIDC/Keycloak
- ABAC via OPA
- Policy Decision API
- transactional outbox
- audit append-only
- OpenTelemetry
- Docker Compose local
- tenant isolation tests
- ADRs 005–007 e threat model

## Security baseline
`JWT org_id -> OPA ABAC -> PostgreSQL RLS -> audit decision log`

## Execução prevista
```bash
cp .env.example .env
docker compose -f infra/docker/docker-compose.yml up -d
npm install
npm run verify
```

> O ambiente de geração não possui Docker; o Compose foi validado estaticamente, não executado.
